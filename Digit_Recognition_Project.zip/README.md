
# ✍️ Recognizing Handwritten Digits with Machine Learning for Smarter AI Applications

## 🧠 Overview
This project demonstrates how Machine Learning can be applied to automatically recognize handwritten digits from images using classical algorithms like Random Forest and Support Vector Machine (SVM). It showcases how AI can enhance digit recognition in sectors such as finance, education, and automation.

## 🎯 Objective
- Build a machine learning model to classify handwritten digits (0–9).
- Compare performance between Random Forest and SVM classifiers.
- Enable smarter applications powered by AI.

## 🗂️ Dataset
- Dataset Used: MNIST Handwritten Digits Dataset  
  Source: [Yann LeCun’s MNIST](http://yann.lecun.com/exdb/mnist/)
- 60,000 training images, 10,000 test images
- Image size: 28x28 grayscale images of handwritten digits

## ⚙️ Tools & Technologies
- Python
- Scikit-learn (Random Forest, SVM)
- NumPy, Pandas, Matplotlib
- Google Colab (for development and testing)

## 🔍 Models Used
- ✅ Random Forest Classifier
- ✅ Support Vector Machine (SVM)

## 📊 Results
- Achieved high classification accuracy using both Random Forest and SVM.
- Performance evaluated using:
  - Accuracy Score
  - Confusion Matrix
  - Classification Report

📝 The implementation is documented in Google Colab.

## 🚀 Google Colab
The entire model was implemented and tested in Google Colab for ease of use and hardware acceleration.  
[Colab Link Placeholder – Add your link here]

## 📌 Future Scope
- Expand to deep learning (CNNs) for higher accuracy
- Build a real-time digit recognition web/mobile app
- Deploy models using TensorFlow Lite or Flask

## 👥 Team Members (Naan Mudhalvan Project)
- N. Mohammed Anas  
- A. Mohammed Kasim  
- Mohammed Sahim  
- Mohammed Yasir

## 🔗 References
- https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.RandomForestClassifier.html
- https://scikit-learn.org/stable/modules/generated/sklearn.svm.SVC.html
- https://www.tensorflow.org/datasets/catalog/mnist

---

🔗 This project is part of the Naan Mudhalvan Skill Development Program.
